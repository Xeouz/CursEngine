# CursEngine 1
## Python, Pixel Game Development Engine. Currently in development stage